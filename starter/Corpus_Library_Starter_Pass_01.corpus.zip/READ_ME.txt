Open Corpus Lab, then Import backup / records, and choose this ZIP.
Program code is deliberately not part of the corpus.
corpus.header.json holds provenance and the append-only change log.
records/ has per-clip labels, calibration and scoped verification.
tracks/ preserves the full editable Unified Prep format 4 records.
references/ and comparisons/ link records by stable identity.
media/ holds unmodified source bytes; .bin files retain the original MIME/name in media/index.json.
A verified group is not approval of the entire clip or a claim of 3D accuracy.
